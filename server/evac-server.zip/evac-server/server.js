// ================== DEPENDENCIES ==================
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const app = express();
app.use(express.json());

app.use(express.static(__dirname));
const Q_TABLE_PATH = path.join(__dirname, 'qtable.json');

// ================== MIDDLEWARE ==================
app.use(cors({ origin: true }));
app.use(bodyParser.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname)));
const PORT = 3000;

// ================== STATE ==================
let users = {};
let blockedRooms = [];
let nodeDanger = {};
let exitLoad = { Node_Exit_Main: 0, Node_Exit_TopRight: 0 };

// ================== WEIGHTS ==================
const W = {
    distance: 1.0,
    danger: 5.0,
    crowd: 3.2,
    exitLoad: 3.5,
    switchPenalty: 8,
    qlWeight: 0.6
};

// ================== GRAPH & POSITIONS ==================
const graph = {
    Node_Passage:             ["Door_Passage_Hall","Door_Passage_Female","Door_Passage_Male","Door_Kitchen_Passage"],
    Node_OpenOffice_Top:      ["Door_Lounge_OpenOfficeTop","Door_OpenOfficeTop_Meeting","Door_OpenOffice_Connection_Right","Door_OpenOffice_Connection_Left"],
    Node_OpenOffice_Bottom:   ["Door_Hall_OpenOffice","Door_OpenOfficeBottom_Meeting","Door_OpenOfficeBottom_Private","Door_OpenOffice_Connection_Right","Door_OpenOffice_Connection_Left"],
    Node_Meeting_TopRight:    ["Door_OpenOfficeTop_Meeting","Door_MeetingTop_Exit"],
    Node_Exit_Main:           ["Door_Hall_Exit_Main"],
    Node_Exit_TopRight:       ["Door_MeetingTop_Exit"],
    Node_FemaleBathroom:      ["Door_Passage_Female"],
    Node_Hall:                ["Door_Passage_Hall","Door_Hall_OpenOffice","Door_Hall_Private","Door_Hall_Exit_Main"],
    Node_Kitchen:             ["Door_Lounge_Kitchen","Door_Kitchen_Passage"],
    Node_PrivateOffice:       ["Door_Hall_Private","Door_OpenOfficeBottom_Private"],
    Node_Lounge:              ["Door_Lounge_Kitchen","Door_Lounge_OpenOfficeTop"],
    Node_MaleBathroom:        ["Door_Passage_Male"],
    Node_Meeting_BottomRight: ["Door_OpenOfficeBottom_Meeting"],
    Door_Lounge_Kitchen:              ["Node_Lounge","Node_Kitchen"],
    Door_Lounge_OpenOfficeTop:        ["Node_Lounge","Node_OpenOffice_Top"],
    Door_Kitchen_Passage:             ["Node_Kitchen","Node_Passage"],
    Door_Passage_Hall:                ["Node_Passage","Node_Hall"],
    Door_Passage_Female:              ["Node_Passage","Node_FemaleBathroom"],
    Door_Passage_Male:                ["Node_Passage","Node_MaleBathroom"],
    Door_Hall_OpenOffice:             ["Node_Hall","Node_OpenOffice_Bottom"],
    Door_Hall_Private:                ["Node_Hall","Node_PrivateOffice"],
    Door_Hall_Exit_Main:              ["Node_Hall","Node_Exit_Main"],
    Door_OpenOfficeTop_Meeting:       ["Node_OpenOffice_Top","Node_Meeting_TopRight"],
    Door_OpenOfficeBottom_Meeting:    ["Node_OpenOffice_Bottom","Node_Meeting_BottomRight"],
    Door_OpenOfficeBottom_Private:    ["Node_PrivateOffice","Node_OpenOffice_Bottom"],
    Door_OpenOffice_Connection_Right: ["Node_OpenOffice_Top","Node_OpenOffice_Bottom"],
    Door_OpenOffice_Connection_Left:  ["Node_OpenOffice_Top","Node_OpenOffice_Bottom"],
    Door_MeetingTop_Exit:             ["Node_Meeting_TopRight","Node_Exit_TopRight"],
};

const positions = {
    Node_Passage:{x:1.537,y:0,z:2.049},
    Node_OpenOffice_Top:{x:-0.275,y:0,z:0.019},
    Node_OpenOffice_Bottom:{x:-0.195,y:0,z:1.329},
    Node_Meeting_TopRight:{x:-2.808,y:0,z:-0.271},
    Node_Exit_Main:{x:0.675,y:0,z:3.009},
    Node_Exit_TopRight:{x:-2.861,y:0,z:-1.071},
    Node_FemaleBathroom:{x:2.121,y:0,z:2.730},
    Node_Hall:{x:0.785,y:0,z:2.349},
    Node_Kitchen:{x:1.595,y:0,z:1.309},
    Node_PrivateOffice:{x:-0.615,y:0,z:2.139},
    Node_Lounge:{x:1.535,y:0,z:0.449},
    Node_MaleBathroom:{x:2.121,y:0,z:1.926},
    Node_Meeting_BottomRight:{x:-2.285,y:0,z:1.479},
    Door_Lounge_Kitchen:{x:1.504,y:0,z:0.712},
    Door_Lounge_OpenOfficeTop:{x:1.332,y:0,z:0.440},
    Door_Kitchen_Passage:{x:1.504,y:0,z:1.644},
    Door_Passage_Hall:{x:1.326,y:0,z:2.099},
    Door_Passage_Female:{x:1.820,y:0,z:2.688},
    Door_Passage_Male:{x:1.809,y:0,z:1.812},
    Door_Hall_OpenOffice:{x:0.710,y:0,z:1.740},
    Door_Hall_Private:{x:-0.360,y:0,z:2.749},
    Door_Hall_Exit_Main:{x:0.719,y:0,z:3.005},
    Door_OpenOfficeTop_Meeting:{x:-1.702,y:0,z:0.015},
    Door_OpenOfficeBottom_Meeting:{x:-1.702,y:0,z:1.470},
    Door_OpenOfficeBottom_Private:{x:-0.584,y:0,z:1.650},
    Door_OpenOffice_Connection_Right:{x:-1.515,y:0,z:0.739},
    Door_OpenOffice_Connection_Left:{x:1.135,y:0,z:0.739},
    Door_MeetingTop_Exit:{x:-2.827,y:0,z:-1.269},
};

// ================== REINFORCEMENT LEARNING (Q-Learning) ==================
let Q = {};
const ALPHA = 0.1;
const GAMMA = 0.95;
const EPISODES = 800;

function initializeQTable() {

    Q = {};

    for (let node in graph) {

        Q[node] = {};

        for (let next of graph[node]) {
            Q[node][next] = 0;
        }
    }
}

function trainQTable() {

    console.log("🧠 Training lightweight RL...");

    const nodeList = Object.keys(graph);

    for (let ep = 0; ep < EPISODES; ep++) {

        let current =
            nodeList[Math.floor(Math.random() * nodeList.length)];

        let steps = 0;

        while (steps < 50) {

            const neighbors = graph[current] || [];

            if (neighbors.length === 0)
                break;

            const next =
                neighbors[Math.floor(Math.random() * neighbors.length)];

            const reward =
                -h(current, next)
                - ((nodeDanger[next] || 0) * 5);

            const future =
                Math.max(
                    ...(graph[next] || [])
                    .map(n => Q[next]?.[n] || 0),
                    0
                );

            Q[current][next] =
                (Q[current][next] || 0)
                + ALPHA * (
                    reward
                    + GAMMA * future
                    - (Q[current][next] || 0)
                );

            current = next;
            steps++;
        }
    }

    console.log("✅ Lightweight RL trained");
}

function getQLScore(path) {

    let score = 0;

    for (let i = 0; i < path.length - 1; i++) {

        const current = path[i];
        const next = path[i + 1];

        score += Q[current]?.[next] || 0;
    }

    return score;
}

// ================== HELPERS ==================
function h(a, b) {
    const pa = positions[a], pb = positions[b];
    if (!pa || !pb) return 9999;
    return Math.sqrt((pa.x - pb.x)**2 + (pa.z - pb.z)**2);
}

function getNodeLoad() {
    const load = {};
    for (let n in graph) load[n] = 0;
    for (let u in users) {
        const r = users[u].room;
        if (r) load[r]++;
    }
    return load;
}

function recalcLoad() {
    exitLoad = { Node_Exit_Main: 0, Node_Exit_TopRight: 0 };
    for (let u in users) {
        const e = users[u].assignedExit;
        if (e) exitLoad[e]++;
    }
}

// ================== DASHBOARD HELPERS (NEW) ==================
function getRoomDensity() {
    const density = {};
    const roomNodes = Object.keys(graph).filter(k => k.startsWith('Node_'));
    for (let n of roomNodes) density[n] = 0;
    for (let u in users) {
        const r = users[u].room;
        if (r && r.startsWith('Node_')) density[r] = (density[r] || 0) + 1;
    }
    return density;
}

function getAlertEvents() {
    const events = [];
    const now = new Date();
    const fmt = (d) => d.toLocaleTimeString('en-GB', { hour12: false });

    for (let [node, level] of Object.entries(nodeDanger)) {
        const name = node.replace('Node_', '').replace(/_/g, ' ');
        if (level >= 8) events.push({ time: fmt(now), msg: `CRITICAL: ${name} danger level ${level}/10`, level: 'critical' });
        else if (level >= 4) events.push({ time: fmt(now), msg: `Elevated danger in ${name} — level ${level}/10`, level: 'warning' });
    }

    for (let room of blockedRooms) {
        const name = room.replace('Node_', '').replace(/_/g, ' ');
        events.push({ time: fmt(now), msg: `Room blocked: ${name}`, level: 'warning' });
    }

    for (let [exit, load] of Object.entries(exitLoad)) {
        if (load > 5) {
            const name = exit.replace('Node_Exit_', '');
            events.push({ time: fmt(now), msg: `High congestion at Exit ${name} — ${load} users`, level: 'warning' });
        }
    }

    const total = Object.keys(users).length;
    if (total > 0) events.push({ time: fmt(now), msg: `${total} active user(s) tracked in building`, level: 'info' });
    events.push({ time: fmt(now), msg: 'Pathfinding engine active — routes nominal', level: 'info' });

    return events;
}

// ================== A* ==================
function astar(start, goal, nodeLoad) {
    if (!graph[start] || !graph[goal]) return [];

    const open = [start];
    const came = {};
    const g = {};
    const f = {};

    for (let n in graph) {
        g[n] = Infinity;
        f[n] = Infinity;
    }

    g[start] = 0;
    f[start] = h(start, goal);

    while (open.length) {
        open.sort((a, b) => f[a] - f[b]);
        const cur = open.shift();

        if (cur === goal) return reconstruct(came, cur);

        for (let nb of (graph[cur] || [])) {
            if (blockedRooms.includes(nb) || (nodeDanger[nb] || 0) >= 8) continue;

            const dangerCost = (nodeDanger[nb] || 0) * W.danger;
            const crowdCost = Math.pow((nodeLoad[nb] || 0), 2) * W.crowd;
            const edgeCost = h(cur, nb) + dangerCost + crowdCost;
            const tentativeG = g[cur] + edgeCost;

            if (tentativeG < g[nb]) {
                came[nb] = cur;
                g[nb] = tentativeG;
                f[nb] = tentativeG + h(nb, goal);
                if (!open.includes(nb)) open.push(nb);
            }
        }
    }
    return [];
}

function reconstruct(came, cur) {
    const p = [cur];
    while (came[cur]) {
        cur = came[cur];
        p.unshift(cur);
    }
    return p;
}

// ================== BEST EXIT ==================
function bestExit(start, currentExit) {
    let bestExitNode = null;
    let bestPath = [];
    let bestScore = Infinity;
    const nodeLoad = getNodeLoad();

    for (let exit of ['Node_Exit_Main', 'Node_Exit_TopRight']) {
        if (blockedRooms.includes(exit) || (nodeDanger[exit] || 0) >= 8) continue;

        const path = astar(start, exit, nodeLoad);
        if (!path.length) continue;

        const switchPenalty = (exit === currentExit) ? 0 : W.switchPenalty;
        const exitLoadPenalty = (exitLoad[exit] || 0) * W.exitLoad;
       const qlScore = getQLScore(path);
        const score = (path.length * W.distance) +
                      exitLoadPenalty +
                      switchPenalty -
                      (qlScore * W.qlWeight);

        if (score < bestScore) {
            bestScore = score;
            bestExitNode = exit;
            bestPath = path;
        }
    }
    return { path: bestPath, exit: bestExitNode };
}

// ================== CLEANUP ==================
setInterval(() => {
    const now = Date.now();
    for (let id in users) {
        if (now - users[id].lastSeen > 45000) delete users[id];
    }
    recalcLoad();
}, 15000);

function loadOrTrainQTable() {
    if (fs.existsSync(Q_TABLE_PATH)) {
        console.log("📂 Loading Q-table...");
        Q = JSON.parse(fs.readFileSync(Q_TABLE_PATH, 'utf8'));

        if (!Q || Object.keys(Q).length === 0) {
            console.log("⚠️ Invalid Q-table, retraining...");
            initializeQTable();
            trainQTable();
            fs.writeFileSync(Q_TABLE_PATH, JSON.stringify(Q));
        } else {
            console.log("✅ Q-table loaded");
        }
    } else {
        console.log("🧠 Training Q-table...");
        initializeQTable();
        trainQTable();
        fs.writeFileSync(Q_TABLE_PATH, JSON.stringify(Q));
        console.log("💾 Q-table saved");
    }
}

// ================== API ROUTES ==================
app.post('/updatePosition', (req, res) => {
    const { userId, room } = req.body;
    if (!userId || !room) return res.status(400).json({ error: "Missing userId or room" });

    if (!users[userId]) users[userId] = { room: null, assignedExit: null, lastSeen: 0, exitLockedUntil: 0 };
    users[userId].room = room;
    users[userId].lastSeen = Date.now();
    res.sendStatus(200);
});

app.get('/path/:uid', (req, res) => {
    const u = users[req.params.uid];
    if (!u || !u.room) return res.json({ path: [], exit: null });

    const nodeLoad = getNodeLoad();
    const result = bestExit(u.room, null);

    if (!result.path.length || !result.exit) {
        console.log("⚠️ RL failed → fallback to A*");
        const exits = ['Node_Exit_Main', 'Node_Exit_TopRight'];
        for (let exit of exits) {
            const fallbackPath = astar(u.room, exit, nodeLoad);
            if (fallbackPath.length > 0) {
                return res.json({ path: fallbackPath, exit: exit, exitLoad });
            }
        }
        return res.json({ path: [], exit: null });
    }

    const now = Date.now();
    const locked = u.exitLockedUntil && now < u.exitLockedUntil;
    let finalExit = result.exit;

    let currentPath = [];
    if (u.assignedExit) {
        currentPath = astar(u.room, u.assignedExit, nodeLoad);
    }

    const improvementThreshold = 2;

    if (locked && u.assignedExit && currentPath.length > 0) {
        const newLength = result.path.length;
        const oldLength = currentPath.length;
        if (newLength < oldLength - improvementThreshold) {
            finalExit = result.exit;
        } else {
            finalExit = u.assignedExit;
        }
    } else {
        finalExit = result.exit;
    }

    if (u.assignedExit !== finalExit) {
        u.assignedExit = finalExit;
        u.exitLockedUntil = now + 15000;
        recalcLoad();
    }

    const finalPath = (finalExit === result.exit)
        ? result.path
        : astar(u.room, finalExit, nodeLoad);

    res.json({ path: finalPath, exit: finalExit, exitLoad });
});

app.post('/blocked', (req, res) => {
    blockedRooms = req.body.rooms || [];
    res.sendStatus(200);
});

app.post('/danger', (req, res) => {
    nodeDanger = req.body.danger || {};
    res.sendStatus(200);
});

// ================== STATUS ==================
app.get('/status', (req, res) => {
    const dangerActive = Object.values(nodeDanger).some(v => v >= 7) || blockedRooms.length > 0;
    const roomDensity = getRoomDensity();

const userRoutes = {};

for (const room in roomDensity) {

    if (roomDensity[room] <= 0) continue;

    const result = bestExit(room, null);

    if (result && result.path.length > 0) {

        userRoutes[room] = result.exit;
    }
}
    
    res.json({
        status: "ok",
        userCount: Object.keys(users).length,
        exitLoad,
        blockedRooms,
        nodeDanger,
        roomDensity: getRoomDensity(),
        userRoutes,
        dangerActive,
        alertEvents: getAlertEvents(),
        crowdEnabled: true,
        reinforcementLearning: true
    });
    console.log("📊 Users:", Object.keys(users).length, "| DangerActive:", dangerActive);
});

app.get('/map', (req, res) => {
    res.json({
        graph: graph,
        positions: positions,
        nodes: Object.keys(graph).filter(key => key.startsWith('Node_'))
    });
});

// ================== UNITY STREAM PROXY ==================
const UNITY_PORT = 4000;
const UNITY_HOST = '127.0.0.1';

app.get('/unitystream', (req, res) => {
    const options = { hostname: UNITY_HOST, port: UNITY_PORT, path: '/stream', method: 'GET' };
    const proxy = http.request(options, (unityRes) => {
        res.writeHead(unityRes.statusCode || 200, {
            'Content-Type': unityRes.headers['content-type'] || 'multipart/x-mixed-replace; boundary=--unityboundary',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',
            'Access-Control-Allow-Origin': '*',
        });
        unityRes.on('data', chunk => { res.write(chunk); if (res.flush) res.flush(); });
        unityRes.on('end', () => res.end());
        req.on('close', () => proxy.destroy());
    });
    proxy.on('error', () => {
        if (!res.headersSent) res.status(503).json({ error: 'Unity stream not available' });
    });
    proxy.end();
});

app.get('/unitysnapshot', (req, res) => {
    const options = { hostname: UNITY_HOST, port: UNITY_PORT, path: '/snapshot', method: 'GET' };
    const proxy = http.request(options, (unityRes) => {
        res.writeHead(unityRes.statusCode || 200, {
            'Content-Type': 'image/jpeg',
            'Cache-Control': 'no-cache',
            'Access-Control-Allow-Origin': '*',
        });
        unityRes.pipe(res);
    });
    proxy.on('error', () => res.status(503).json({ error: 'Unity not available' }));
    proxy.end();
});

// ================== CERT & HTTPS ==================
app.get('/cert', (req, res) => {
    const certFile = path.join(__dirname, 'cert.pem');
    if (!fs.existsSync(certFile)) return res.status(404).send('Certificate not found');

    const pem = fs.readFileSync(certFile, 'utf8');
    const base64 = pem.replace(/-----BEGIN CERTIFICATE-----/g, '')
                       .replace(/-----END CERTIFICATE-----/g, '')
                       .replace(/\s+/g, '');

    const mobileconfig = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PayloadContent</key>
  <array>
    <dict>
      <key>PayloadCertificateFileName</key><string>evac-server.cer</string>
      <key>PayloadContent</key><data>${base64}</data>
      <key>PayloadDescription</key><string>Evacuation Server CA Certificate</string>
      <key>PayloadDisplayName</key><string>Evac Server (192.168.8.150)</string>
      <key>PayloadIdentifier</key><string>com.evacserver.cert</string>
      <key>PayloadType</key><string>com.apple.security.root</string>
      <key>PayloadUUID</key><string>A1B2C3D4-E5F6-7890-ABCD-EF1234567890</string>
      <key>PayloadVersion</key><integer>1</integer>
    </dict>
  </array>
  <key>PayloadDescription</key><string>Install the Evacuation Server certificate</string>
  <key>PayloadDisplayName</key><string>Evac Server Certificate</string>
  <key>PayloadIdentifier</key><string>com.evacserver.profile</string>
  <key>PayloadType</key><string>Configuration</string>
  <key>PayloadUUID</key><string>B2C3D4E5-F6A7-8901-BCDE-F12345678901</string>
  <key>PayloadVersion</key><integer>1</integer>
</dict>
</plist>`;

    res.setHeader('Content-Type', 'application/x-apple-aspen-config');
    res.setHeader('Content-Disposition', 'attachment; filename="evac-server.mobileconfig"');
    res.send(mobileconfig);
});

// ================== START SERVERS ==================
// 🚀 Start HTTP immediately
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Fire Navigation Server running on http://192.168.4.2:${PORT}`);
    console.log(`   Features: Danger + Crowd + Exit Load + RL`);
});

// 🔒 Start HTTPS immediately
const certPath = path.join(__dirname, 'cert.pem');
const keyPath = path.join(__dirname, 'key.pem');
const HTTPS_PORT = 3443;

if (fs.existsSync(certPath) && fs.existsSync(keyPath)) {
    const sslOptions = {
        cert: fs.readFileSync(certPath),
        key: fs.readFileSync(keyPath)
    };
    https.createServer(sslOptions, app).listen(HTTPS_PORT, '0.0.0.0', () => {
        console.log(`🔒 HTTPS Server running on https://192.168.4.2:${HTTPS_PORT}`);
    });
} else {
    console.log('⚠️ No SSL certificates found. HTTPS disabled.');
}

// 🧠 Load/train Q-table AFTER server is already listening
setImmediate(() => {
    loadOrTrainQTable();
});