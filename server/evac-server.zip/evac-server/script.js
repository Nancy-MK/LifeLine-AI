const BASE = "http://192.168.4.2:3000";

async function updateDashboard() {
  try {
    const res = await fetch(BASE + "/status");
    const data = await res.json();

    // USERS
    document.getElementById("users").textContent = data.userCount;

    // FIRE STATUS
    const fire = document.getElementById("fire-status");
    if (data.dangerActive) {
      fire.textContent = "🔥 FIRE DETECTED";
      fire.className = "status-text danger";
    } else {
      fire.textContent = "✅ SAFE";
      fire.className = "status-text safe";
    }

    // EXIT LOAD
    const exitsDiv = document.getElementById("exits");
    exitsDiv.innerHTML = "";
    Object.entries(data.exitLoad).forEach(([exit, count]) => {
      const el = document.createElement("div");
      el.textContent = exit + ": " + count;
      exitsDiv.appendChild(el);
    });

    // ROOM DENSITY
    const roomsDiv = document.getElementById("rooms");
    roomsDiv.innerHTML = "";
    Object.entries(data.roomDensity).forEach(([room, count]) => {
      const el = document.createElement("div");
      el.textContent = room + ": " + count;
      roomsDiv.appendChild(el);
    });

  } catch (e) {
    console.log("Server error");
  }
}

// refresh every second
setInterval(updateDashboard, 1000);