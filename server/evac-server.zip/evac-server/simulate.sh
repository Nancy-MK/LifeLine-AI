#!/bin/bash

SERVER="http://192.168.100.5:3000"
SERVER="http://localhost:3000"
ROOMS=("Hall" "Lounge" "Kitchen" "Passage" "PrivateOffice" "OpenOffice_Bottom" "OpenOffice_Top" "MeetingTopRight" "FemaleBathroom" "MaleBathroom")
NUM_USERS=15

echo "Registering $NUM_USERS users in random rooms..."

for i in $(seq 1 $NUM_USERS); do
  ROOM=${ROOMS[$RANDOM % ${#ROOMS[@]}]}
  USER_ID="fake-user-$(printf '%03d' $i)"
  curl -s -X POST $SERVER/updatePosition \
    -H "Content-Type: application/json" \
    -d "{\"userId\":\"$USER_ID\",\"room\":\"$ROOM\"}" > /dev/null
  echo "  $USER_ID → $ROOM"
done

echo ""
echo "Fetching paths to assign exits..."
for i in $(seq 1 $NUM_USERS); do
  curl -s $SERVER/path/fake-user-$(printf '%03d' $i) > /dev/null
done

echo ""
echo "Exit loads:"
curl -s $SERVER/exitLoad
echo ""
echo "Done! Trigger fire on your iPhone now."
ROOMS=("Hall" "Lounge" "Kitchen" "Passage" "PrivateOffice" "OpenOffice_Bottom" "OpenOffice_Top" "MeetingTopRight" "MeetingBottomRight" "FemaleBathroom" "MaleBathroom")

NUM_USERS=15

echo "Registering $NUM_USERS users in random rooms..."

for i in $(seq 1 $NUM_USERS); do
  ROOM=${ROOMS[$RANDOM % ${#ROOMS[@]}]}
  USER_ID="user-$(cat /proc/sys/kernel/random/uuid 2>/dev/null || uuidgen | tr '[:upper:]' '[:lower:]')"
  
  curl -s -X POST $SERVER/updatePosition \
    -H "Content-Type: application/json" \
    -d "{\"userId\":\"$USER_ID\",\"room\":\"$ROOM\"}" > /dev/null
  
  echo "  $USER_ID → $ROOM"
done

echo ""
echo "Fetching paths (server assigns exits)..."

# Get all user IDs from server and fetch their paths
for i in $(seq 1 $NUM_USERS); do
  curl -s $SERVER/path/user-$i > /dev/null
done

echo ""
echo "Current exit loads:"
curl -s $SERVER/exitLoad
echo ""
echo "Done! Now trigger fire on your iPhone to see crowd control in action."

